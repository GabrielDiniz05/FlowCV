package com.gedai.flowcv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlowcvApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlowcvApplication.class, args);
	}

}
