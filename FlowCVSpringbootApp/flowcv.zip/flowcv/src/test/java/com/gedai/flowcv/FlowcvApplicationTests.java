package com.gedai.flowcv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowcvApplicationTests {

	@Test
	void contextLoads() {
	}

}
